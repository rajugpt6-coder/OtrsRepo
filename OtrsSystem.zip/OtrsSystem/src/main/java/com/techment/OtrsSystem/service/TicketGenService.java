package com.techment.OtrsSystem.service;

import com.techment.OtrsSystem.domain.TicketGen;
//import com.techment.OtrsSystem.domain.Title;
import com.techment.OtrsSystem.repository.TicketGenRepository;
//import com.techment.OtrsSystem.repository.TitleRepository;
import com.techment.OtrsSystem.repository.UserRepository;
import com.techment.OtrsSystem.security.JwtProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class TicketGenService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TicketService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtProvider jwtProvider;

    @Autowired
    private TicketGenRepository ticketGenRepository;

    @Autowired
    private UserService userService;

//    @Autowired
//    private TitleRepository titleRepository;

    public TicketGen generateTicket(String category, long id,long issueId, String token, String titles, String description){
        LOGGER.info("Admin attempting create category");
       TicketGen cat=null;
       Optional<TicketGen> categoryOptional= ticketGenRepository.findByCategoryName(category);
        if(userRepository.existsById(id) &&
                userRepository.findById(id).get().getEmail().equalsIgnoreCase(jwtProvider.getUsername(userService.filterToken(token)))&&
                userRepository.findById(id).get().isFlag()&&!categoryOptional.isPresent()
        ) {
//            ArrayList<Title> titleArrayList = new ArrayList<>();
//            for(String title : titles){
//                Title title1 = titleRepository.findByTitleName(title).get();
//                titleArrayList.add(title1);
//            }

            cat = ticketGenRepository.save(new TicketGen(issueId, category, true, titles, description, Timestamp.valueOf(LocalDateTime.now()), userRepository.findById(id).get().getEmail()));
        }
        return cat;
    }

    public String deleteTicket(long issueId, long id, String token){
        LOGGER.info("Admin attempting delete department");
        Optional<TicketGen> category= ticketGenRepository.findById(issueId);
        String rtn="";
        if(userRepository.existsById(id) &&
                userRepository.findById(id).get().getEmail().equalsIgnoreCase(jwtProvider.getUsername(userService.filterToken(token)))&&
                userRepository.findById(id).get().isFlag()&& category.isPresent()
        ) {
            TicketGen ticketGenOb = category.get();
            ticketGenOb.setUpdatedBy(userRepository.findById(id).get().getEmail());
            ticketGenOb.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
            ticketGenOb.setFlag(false);
            ticketGenRepository.save(ticketGenOb);
            rtn="{\"status\":\"success\",\"msg\":\"TicketGen has been deleted successfully\"}";
        }
        else{
            rtn="{\"status\":\"failure\",\"msg\":\"Something went wrong !!\"}";
        }
        return rtn;

    }
}
