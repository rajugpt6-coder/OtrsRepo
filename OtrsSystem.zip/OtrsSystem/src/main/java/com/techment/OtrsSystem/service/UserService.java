package com.techment.OtrsSystem.service;

import com.techment.OtrsSystem.domain.*;
import com.techment.OtrsSystem.repository.*;
import com.techment.OtrsSystem.security.JwtProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class UserService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
    private static final boolean FLAG = false;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GenderRepository genderRepository;

    @Autowired
    private FeaturesRepository featuresRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private DesignationRepository designationRepository;

    @Autowired
    private JwtProvider jwtProvider;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private LogRepository logRepository;


    public Optional<User> signup(String email, String firstName, String middleName, String lastName,
                                 String employeeId, String phoneNumber, String workingNumber, String extensionLandline,
                                 String landlineNumber, long genderId, long designationId, long department) {
        LOGGER.info("New user attempting to sign up");
        Optional<User> user = Optional.empty();
        String password = GenerateSecurePassword.generatePassword(10);
        LOGGER.info(password);

        ArrayList<Features> features = new ArrayList<>();
        features.add(featuresRepository.findByFeatureName("F_UPDATE_PASSWORD").get());

        if (!userRepository.findByEmail(email).isPresent()) {
            try {
//            Optional<Features> features =
                Optional<Gender> gender = genderRepository.findById(genderId);
                sendEmail(email, password);
                user = Optional.of(userRepository.save(new User(email,
                        passwordEncoder.encode(password),
                        firstName,
                        middleName,
                        lastName,
                        employeeId,
                        phoneNumber,
                        workingNumber,
                        extensionLandline,
                        landlineNumber,
                        genderRepository.findById(genderId).get(),
                        designationRepository.findById(designationId).get(),
                        departmentRepository.findById(department).get(),
                        FLAG,
                        Timestamp.valueOf(LocalDateTime.now()),
                        firstName + " " + lastName,
                        features

                )));
                logRepository.save(new Log(user.get().getId(), 1, Timestamp.valueOf(LocalDateTime.now()), "user signed up", Timestamp.valueOf(LocalDateTime.now()),
                        user.get().getEmail(), true));
            } catch (MailException mailException) {
                return null;
            }
        }
        return user;
    }

    public Optional<String> signin(String username, String password) {
        LOGGER.info("New user attempting to sign in");
        String token = "";
        Optional<User> user = userRepository.findByEmail(username);
        String rtn = "";

        if (user.isPresent()) {
            try {
                authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
                token = jwtProvider.createToken(username, user.get().getFeatures());
//                rtn = "{\"status\":\"success\"," +
//                        "\"id\":" + "\"" + user.get().getId() + "\"" +
//                        ",\"email\":" + "\"" + user.get().getEmail() + "\"" +
//                        ",\"phoneNo\":" + "\"" + user.get().getPhoneNumber() + "\"" +
//                        ",\"feature\":" + "\"" + user.get().getFeatures().get(0).getFeatureName() + "\"" +
//                        ",\"token\":" + "\"" + token + "\"" +
//                        '}';


                rtn = "{\"status\":\"success\"," +
                        "\"id\":" + "\"" + user.get().getId() + "\"" +
                        ",\"email\":" + "\"" + user.get().getEmail() + "\"" +
                        ",\"phoneNo\":" + "\"" + user.get().getPhoneNumber() + "\"" +
                        ",\"features\": [" ;
                for(int i=0;i<user.get().getFeatures().size();i++){
                    rtn+="{"+
                            "\"feature \":"+"\""+ user.get().getFeatures().get(i).getFeatureName() + "\"" +
                            "}";
                    if(i!=user.get().getFeatures().size()-1){
                        rtn+=",";
                    }
                }
                rtn+="]"+",\"token\":" + "\"" + token + "\"" +
                        "}";
            } catch (AuthenticationException e) {
                rtn = "{\"status\":\"failure\",\"msg\":\"Incorrect user name or password !!\"}";
            }
        } else {
            rtn = "{\"status\":\"failure\",\"msg\":\"please sign up !!\"}";
        }
        return Optional.of(rtn);
    }

    public String forgotPassword(String email) {
        LOGGER.info("User forgot Password");
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isPresent() && user.get().isFlag()) {

            String password = GenerateSecurePassword.generatePassword(10);
            //send password to mail
            try {
                sendEmail(user.get().getEmail(), password);
                user.get().setPassword(passwordEncoder.encode(password));
                return "{\"status\":\"success\",\"msg\":\"New password sent to your email. Please check !!\"}";
            } catch (MailException mailException) {
                return "{\"status\":\"failure\",\"msg\":\"Unable to send mail !!\"}";
            }
        }
        return "{\"status\":\"failure\",\"msg\":\"Incorrect email !!\"}";
    }

    public String updatePassword(long id, String oldPassword, String newPassword, String token) {
        LOGGER.info("User trying to  update password");

        if (userRepository.existsById(id) ) {
            try {


                User user = userRepository.findById(id).get();
                authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), oldPassword));
                user.setFlag(true);
                user.setPassword(passwordEncoder.encode(newPassword));
                userRepository.save(user);
                return "{\"status\":\"success\",\"msg\":\"Password updates successfully !!\"}";

            } catch (AuthenticationException e) {
                return "{\"status\":\"failure\",\"msg\":\"Something went wrong !!\"}";
            }
        }
        return "{\"status\":\"failure\",\"msg\":\"Something went wrong !!\"}";
    }

    public String filterToken(String token) {
        return token.replace("Bearer", "").trim();
    }


    public void sendEmail(String email, String password) throws MailException {

        LOGGER.info("Trying to send email");

        /*
         * This JavaMailSender Interface is used to send Mail in Spring Boot. This
         * JavaMailSender extends the MailSender Interface which contains send()
         * function. SimpleMailMessage Object is required because send() function uses
         * object of SimpleMailMessage as a Parameter
         */

        SimpleMailMessage mail = new SimpleMailMessage();
        mail.setTo(email);
//        mail.setCc(user.getCcMailAddress());

        mail.setSubject("Password");
        mail.setText("YOU HAVE REGISTERED SUCCESSFULLY " +
                "YOUR PASSWORD IS : " +
                password);


        /*
         * This send() contains an Object of SimpleMailMessage as an Parameter
         */
        javaMailSender.send(mail);
    }

    public void updateProfile(long id, String newPhoneNumber, String landline,
                              String workingNumber, String extension, long designation, String token) {
        token = filterToken(token);
        if (userRepository.existsById(id) &&
                userRepository.findById(id).get().getEmail().equalsIgnoreCase(jwtProvider.getUsername(token))
                && userRepository.findById(id).get().isFlag()) {

            User user = userRepository.findById(id).get();
            if (newPhoneNumber != null)
                user.setPhoneNumber(newPhoneNumber);

            if (landline != null)
                user.setLandlineNumber(landline);

            if (extension != null)
                user.setExtensionLandline(extension);

            if (workingNumber != null)
                user.setWorkingNumber(workingNumber);

            if (departmentRepository.existsById(designation))
                user.setDesignation(designationRepository.findById(designation).get());

            user.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
            user.setUpdatedBy(user.getFirstName() + " " + user.getLastName());
            userRepository.save(user);
        }
    }

    public Page<User> getUsersByFeatures(List<String> features, Pageable pageable) {
        LOGGER.info("Fetching users by features");
        ArrayList<Features> featuresArrayList = new ArrayList<>();

        for(String features1 : features){
            Features featureObj = featuresRepository.findByFeatureName(features1).get();
            featuresArrayList.add(featureObj);
        }

        return userRepository.findByFeaturesContaining(featuresArrayList, pageable);

    }

    public void deactivateUser(long id) {
        LOGGER.info("Trying to deactivate user");
        if(userRepository.existsById(id)) {
            User user = userRepository.findById(id).get();
            user.setFlag(false);
        }
    }

    public void activateUser(long id) {
        LOGGER.info("Trying to activate user");
        if(userRepository.existsById(id)) {
            User user = userRepository.findById(id).get();
            user.setFlag(true);
        }
    }

    public void setFeaturesAccess(long id, List<String> features) {
        LOGGER.info("user trying to add features");
        if(userRepository.existsById(id)) {
            User user = userRepository.findById(id).get();
            ArrayList<Features> featuresArrayList = new ArrayList<>();
            for (String feature : features) {
                Features featuresObj = featuresRepository.findByFeatureName(feature).get();
                featuresArrayList.add(featuresObj);
            }
            List<Features> prevFeatures = user.getFeatures();

            for (Features features1 : prevFeatures) {
                if (!featuresArrayList.contains(features1)) {
                    featuresArrayList.add(features1);
                }
            }
            user.setFeatures(featuresArrayList);
            userRepository.save(user);
        }
    }

    public void removeFeatureAccess(long id, List<String> features) {
        LOGGER.info("user trying to remove features");
        if(userRepository.existsById(id)) {
            ArrayList<Features> featureRemoveList = new ArrayList<>();
            for (String feature : features) {
                Features featureObj = featuresRepository.findByFeatureName(feature).get();
                featureRemoveList.add(featureObj);
            }

            ArrayList<Features> allUsersFeatures = new ArrayList<>();
            User user = userRepository.findById(id).get();

             for(Features features1 : user.getFeatures()) {
                 allUsersFeatures.add(features1);
             }


            for (Features removeFeature : featureRemoveList) {
                for (Features userFeature : allUsersFeatures) {
                    if (removeFeature.equals(userFeature)) {
                        allUsersFeatures.remove(removeFeature);
                        break;
                    }
                }
            }
            user.setFeatures(allUsersFeatures);
            userRepository.save(user);
        }
    }


    public Page<User> getAll(Pageable pageable) throws NoSuchElementException {
        LOGGER.info("Request to retrieve all users");
        return userRepository.findAll(pageable);
    }

    public Optional<User> findUserById (long id) {
        LOGGER.info("Trying to find user by id");
        return userRepository.findById(id);
    }

    public User findUserByEmail(String email, String token)  throws NoSuchElementException {
        LOGGER.info("Trying to find user by email");
        if(email.equalsIgnoreCase(jwtProvider.getUsername(filterToken(token)))) {
            return userRepository.findByEmail(email).orElseThrow(() ->
                    new NoSuchElementException("No users found"));
        }
        return null;
    }


    //searching code

    public Page<User> findUsersByEmployeeId(String employeeId, Pageable pageable){
        LOGGER.info("Trying to find users by employee id");
        return userRepository.findByEmployeeIdIgnoreCaseContaining(employeeId, pageable);
    }

    public Page<User> findUsersByFirstName(String firstName, Pageable pageable){
        LOGGER.info("Trying to find users by first name");
        return userRepository.findByFirstNameIgnoreCaseContaining(firstName, pageable);
    }

    public Page<User> findUsersByFlag(boolean flag, Pageable pageable){
        LOGGER.info("Trying to find users by activation");
        return userRepository.findByFlag(flag, pageable);
    }

    public Page<User> findByPhoneNumber(String phoneNumber, Pageable pageable) {
        LOGGER.info("Trying to find users by phone number");
        return userRepository.findByPhoneNumberIgnoreCaseContaining(phoneNumber, pageable);
    }

    public User findByEmail(String email){
        LOGGER.info("Trying to find users by email");
        return userRepository.findByEmail(email).get();
    }

    public Page<User> findByDepartment(String department, Pageable pageable){
        LOGGER.info("Trying to find users by department");
        return userRepository.findByDepartment(departmentRepository.findByDepartmentName(department).get(), pageable);
    }

    public Page<User> findByDesignation(String designation, Pageable pageable){
        LOGGER.info("Trying to find users by designation");
        return userRepository.findByDesignation(designationRepository.findByDesignationName(designation).get(), pageable);
    }

}