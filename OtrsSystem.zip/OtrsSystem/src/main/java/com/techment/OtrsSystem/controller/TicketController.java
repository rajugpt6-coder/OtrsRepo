package com.techment.OtrsSystem.controller;

import com.techment.OtrsSystem.domain.Ticket;
import com.techment.OtrsSystem.service.TicketService;
import com.techment.OtrsSystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/users/{id}")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @Autowired
    private UserService userService;

    @PostMapping("/ticket")
    @PreAuthorize("hasAuthority('F_RAISE_TICKET')")
    @ResponseStatus(HttpStatus.CREATED)
    public Optional<Ticket> raiseTicket(@RequestBody @Validated TicketDto ticketDto, @PathVariable("id") long id,
                                        @RequestHeader(value = "Authorization") String token){

        return Optional.ofNullable(ticketService.createTicket(ticketDto.getCategory(), ticketDto.getDescription(),
                ticketDto.getStatus(),
                ticketDto.getSubject(), id, ticketDto.getTitle(),  token, ticketDto.getAttachment()));

    }

    @GetMapping("/tickets")
    @PreAuthorize("hasAuthority('F_GET_TICKETS')")
    public Page<Ticket> getTickets(@PathVariable("id") long id, Pageable pageable, @RequestHeader(value = "Authorization") String token){
        return ticketService.findTicketsByUserId(id, pageable, token);
//            PagedResources<Ticket> result =  pagedResourcesAssembler.toResource(tickets, assembler);
//            return ticketService.findTicketsByUserId(id, pageable) ;
//        }
//        return null;
    }

    @GetMapping("/tickets/all")
    @PreAuthorize("hasAuthority('F_GET_ALL_TICKETS')")
    public Page<Ticket> getAllTickets(Pageable pageable) {
        return ticketService.getAllTickets(pageable);
    }

    @GetMapping("/tickets/{ticketId}")
    @PreAuthorize("hasAuthority('F_GET_TICKET_DETAILS')")
    public Ticket getTicketDetails (@PathVariable("ticketId") Long ticketId, @PathVariable("id") long userId,
                                    @RequestHeader(value = "Authorization") String token) {

        return ticketService.findTicketById(ticketId, userId, token);

    }

    @GetMapping("/tickets/{ticketId}/status")
    @PreAuthorize("hasAuthority('F_GET_TICKET_STATUS')")
    public String getTicketStatus(@PathVariable("userId") long userId, @PathVariable("ticketId") long ticketId,
                                 @RequestHeader(value = "Authorization") String token) {
        return ticketService.findTicketStatus(userId, ticketId, token);
    }

    @PatchMapping("/tickets/{ticketId}/status/{status}")
    @PreAuthorize("hasAuthority('F_UPDATE_TICKET_STATUS')")
    @ResponseStatus(HttpStatus.CREATED)
    public Optional<String> updateTicketStatus(@PathVariable("ticketId") long ticketId, @PathVariable("status") String status, @PathVariable("id") long id,
                                         @RequestHeader(value = "Authorization") String token) {
        return ticketService.updateStatus(status, ticketId, token, id);

    }

    @GetMapping("/tickets/resolveTickets")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_RESOLVE')")
    public Page<Ticket> getTicketsToResolve(@PathVariable("id") long userId, @RequestHeader("Authorization") String token,
                                            Pageable pageable) {
        return ticketService.getTicketsForResolve(userId, token, pageable);
    }

    @PostMapping("/assignTicket/ticket/{ticketId}")
    @PreAuthorize("hasAuthority('F_ASSIGN_TICKET')")
    @ResponseStatus(HttpStatus.OK)
    public void assignTicket (@PathVariable("id") long userId, @PathVariable("ticketId") long ticketId,
                               @RequestHeader("Authorization") String token) {
        ticketService.assignTicket(userId, ticketId, token);

    }

    @GetMapping("/assignTickets")
    @PreAuthorize("hasAuthority('F_GET_ASSIGNED_TICKETS')")
    public Page<Ticket> getAssignedTickets(@PathVariable("id") long userId,
                                           @RequestHeader("Authorization") String token, Pageable pageable){
        return ticketService.getAssignedTickets(userId,token, pageable);
    }

    @PatchMapping("/tickets/{ticketId}/deactivate")
    @PreAuthorize("hasAuthority('F_DEACTIVATE_TICKET_BY_USER')")
    public void deactivateTicketByUser(@PathVariable("id") long userId, @PathVariable("ticketId") long ticketId,
                                       @RequestHeader("Authorization") String token) {
        ticketService.deactivateTicketByUser(userId, ticketId, token);
    }

    @PatchMapping("/tickets/{ticketId}/admin/deactivate")
    @PreAuthorize("hasAuthority('F_DEACTIVATE_TICKET_BY_ADMIN')")
    public void deactivateTicketByAdmin(@PathVariable("ticketId") long ticketId){
        ticketService.deactivateTicketByAdmin(ticketId);
    }

        //searching code

    @GetMapping("/tickets/search/subject/{subject}")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_BY_TITLE')")
    public Page<Ticket> getTicketsByTitle(@PathVariable("subject") String subject, Pageable pageable) {
        return ticketService.findTicketsBySubject(subject, pageable);
    }

    @GetMapping("/tickets/search/status/{status}")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_BY_STATUS')")
    public Page<Ticket> getTicketsByStatus(@PathVariable("status") String status, Pageable pageable) {
        return ticketService.findTicketsByStatus(status, pageable);
    }

    @GetMapping("/tickets/search/user/subject/{subject}")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_BY_TITLE_AND_USER')")
    public Page<Ticket> getTicketsByTitleAndUser(@PathVariable("id") long id, @PathVariable("subject") String subject,
                                                 @RequestHeader(value = "Authorization") String token, Pageable pageable){
        return ticketService.findTicketsBySubjectAndUser(subject, id, pageable, token);
    }

    @GetMapping("/tickets/search/user/status/{status}")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_BY_STATUS_AND_USER')")
    public Page<Ticket> getTicketsByStatusAndUser(@PathVariable("id") long id, @PathVariable("status") String status,
                                                  @RequestHeader(value = "Authorization") String token, Pageable pageable){
        return ticketService.findTicketsByUserAndStatus(status, id, pageable, token);
    }

    @GetMapping("/tickets/search/dueDate/{dueDate}")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_BY_DUE_DATE')")
    public Page<Ticket> getTicketsByDueDate(@PathVariable("dueDate") String dueDate, Pageable pageable) {
        return ticketService.findTicketsByDueDate(Timestamp.valueOf(dueDate), pageable);
    }

    @GetMapping("/tickets/search/category/{category}")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_BY_CATEGORY')")
    public Page<Ticket> getTicketsByCategory(@PathVariable("category") String category, Pageable pageable) {
        return ticketService.findTicketsByCategory(category, pageable);
    }

    @GetMapping("/tickets/search/dueDate/{createdAt}")
    @PreAuthorize("hasAuthority('F_GET_TICKETS_BY_CREATED_DATE')")
    public Page<Ticket> getTicketsByCreatedDate(@PathVariable("createdAt") String createdAt, Pageable pageable) {
        return ticketService.findTicketsByCreatedAt(Timestamp.valueOf(createdAt), pageable);
    }


    // Analytics code below

    @GetMapping("/ticktes/count")
    @PreAuthorize("hasAuthority('F_GET_TICKET_COUNT')")
    public long getIsuueCount() {
        return ticketService.countAllTickets();
    }

    @GetMapping("/tickets/{category}/count")
    @PreAuthorize("hasAuthority('F_GET_TICKET_COUNT_BY_CATEGORY')")
    public long getIssueByCategory(@PathVariable("category") String category ) {
        return ticketService.countTicketByCategory(category);
    }

    @GetMapping("/tickets/{category}/{status}")
    @PreAuthorize("hasAuthority('F_GET_TICKET_COUNT_BY_CATEGORY_AND_STATUS')")
    public long getIssueBycategoryAndStatus (@PathVariable("category") String category, @PathVariable("status") String status ) {
        return ticketService.countTicketByCategoryAndStatus(category, status);
    }


}
