package com.techment.OtrsSystem.domain;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "tbl_log_record")
public class Log {
    @Id
    @GeneratedValue
    @Column(name = "pk_log_id")
    private long id;

    @Column(name = "user_id")
    private long userId;

    @Column(name = "form_id")
    private long formId;

    @Column(name = "action_time")
    private Timestamp actionTime;

    @Column(name = "action")
    private String action;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "l_flag")
    private boolean lFlag;

    public Log(long userId, long formId, Timestamp actionTime, String action, Timestamp createdAt, String createdBy,  boolean lFlag) {
        this.userId = userId;
        this.formId = formId;
        this.actionTime = actionTime;
        this.action = action;
        this.createdAt = createdAt;

        this.createdBy = createdBy;

        this.lFlag = lFlag;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getFormId() {
        return formId;
    }

    public void setFormId(long formId) {
        this.formId = formId;
    }

    public Timestamp getActionTime() {
        return actionTime;
    }

    public void setActionTime(Timestamp actionTime) {
        this.actionTime = actionTime;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public boolean islFlag() {
        return lFlag;
    }

    public void setlFlag(boolean lFlag) {
        this.lFlag = lFlag;
    }
}
