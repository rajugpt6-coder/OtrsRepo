package com.techment.OtrsSystem.controller;

import com.techment.OtrsSystem.domain.Department;
import com.techment.OtrsSystem.service.DepartmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping
public class DepartmentController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    public DepartmentService departmentService;

    @PostMapping("createDepartment/{id}")
    @PreAuthorize("hasAuthority('F_CREATE_DEPARTMENT')")
    @ResponseStatus(HttpStatus.CREATED)
    public Optional<Department> createDepartment(@RequestBody @Validated DepartmentDto departmentDto, @PathVariable("id") Long id,
                                               @RequestHeader(value = "Authorization") String token){
        LOGGER.info("authorised");
        return Optional.ofNullable(departmentService.createDepartment(departmentDto.getDepartmentName(), id, token));

    }

    @PatchMapping("/delete/department/{id}/{departmentName}")
    @PreAuthorize("hasAuthority('F_DELETE_DEPARTMENT')")
    @ResponseStatus(HttpStatus.CREATED)
    public String deleteDepartment(@PathVariable("departmentName") String departmentName, @PathVariable("id") Long id,
                                               @RequestHeader(value = "Authorization") String token){
        LOGGER.info("authorised");
        return departmentService.deleteDepartment(departmentName, id, token);

    }

    @GetMapping("/departments")
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();

    }
}
