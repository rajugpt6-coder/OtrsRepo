package com.techment.OtrsSystem.service;

import com.techment.OtrsSystem.domain.Category;
//import com.techment.OtrsSystem.domain.Title;
import com.techment.OtrsSystem.repository.CategoryRepository;
//import com.techment.OtrsSystem.repository.TitleRepository;
import com.techment.OtrsSystem.repository.UserRepository;
import com.techment.OtrsSystem.security.JwtProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TicketService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtProvider jwtProvider;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private UserService userService;

//    @Autowired
//    private TitleRepository titleRepository;

    public Category createCategory(String category, long id, String token, String titles, String description){
        LOGGER.info("Admin attempting create category");
       Category cat=null;
       Optional<Category> categoryOptional=categoryRepository.findByCategoryName(category);
        if(userRepository.existsById(id) &&
                userRepository.findById(id).get().getEmail().equalsIgnoreCase(jwtProvider.getUsername(userService.filterToken(token)))&&
                userRepository.findById(id).get().isFlag()&&!categoryOptional.isPresent()
        ) {
//            ArrayList<Title> titleArrayList = new ArrayList<>();
//            for(String title : titles){
//                Title title1 = titleRepository.findByTitleName(title).get();
//                titleArrayList.add(title1);
//            }

            cat = categoryRepository.save(new Category(category, true, titles, description, Timestamp.valueOf(LocalDateTime.now()), userRepository.findById(id).get().getEmail()));
        }
        return cat;
    }

    public String deleteCategory(String categoryName, long id, String token){
        LOGGER.info("Admin attempting delete department");
        Optional<Category> category=categoryRepository.findByCategoryName(categoryName);
        String rtn="";
        if(userRepository.existsById(id) &&
                userRepository.findById(id).get().getEmail().equalsIgnoreCase(jwtProvider.getUsername(userService.filterToken(token)))&&
                userRepository.findById(id).get().isFlag()&& category.isPresent()
        ) {
            Category categoryOb = category.get();
            categoryOb.setUpdatedBy(userRepository.findById(id).get().getEmail());
            categoryOb.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
            categoryOb.setFlag(false);
            categoryRepository.save(categoryOb);
            rtn="{\"status\":\"success\",\"msg\":\"Category has been deleted successfully\"}";
        }
        else{
            rtn="{\"status\":\"failure\",\"msg\":\"Something went wrong !!\"}";
        }
        return rtn;

    }
}
