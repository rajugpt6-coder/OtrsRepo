package com.techment.OtrsSystem.repository;

import com.techment.OtrsSystem.domain.AssignTicket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AssignTicketRepository extends JpaRepository<AssignTicket , Long> {
}
