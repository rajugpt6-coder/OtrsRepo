
package com.techment.OtrsSystem.domain;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Blob;
import java.sql.Timestamp;

@Entity
@Table(name = "tbl_ticket_raise")
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "pk_ticketr_id")
    private long id;

    @Column(name = "ticketr_sub")
    @NotNull
    private String subject;

    @Column(name = "ticketr_desc")
    @NotNull
    private String ticketDescription;

    @Column(name = "ticket_r_date")
    private Timestamp ticketDate;

    @Column(name = "created_at")
    @NotNull
    private Timestamp createdAt;

    @Column(name = "created_by")
    @NotNull
    private String createdBy;

    @Column(name = "due_date")
    @NotNull
    private Timestamp dueDate;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @Column(name = "tr_flag")
    private boolean ticketActivationFlag;

    @ManyToOne
    @JoinColumn(name = "tr_status")
    private Status status;

    @ManyToOne
    @JoinColumn(name = "fk_ticket")
    @NotNull
    private Category category;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_to")
    private User assignedUser;

//    @ManyToOne
//    @JoinColumn(name = "fk_title")
//    private Title title;

    @Column(name = "attachment")
    private Blob attachment;


    protected Ticket(){}


    public Ticket(@NotNull String subject, @NotNull String ticketDescription, @NotNull Timestamp createdAt,
                  @NotNull String createdBy, @NotNull Timestamp dueDate, @NotNull boolean ticketActivationFlag,
                  @NotNull Status status, @NotNull Category category, User user,  Blob attachment) {

        this.subject = subject;
        this.ticketDescription = ticketDescription;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.dueDate = dueDate;
        this.ticketActivationFlag = ticketActivationFlag;
        this.status = status;
        this.category = category;
        this.user = user;
        this.attachment = attachment;
    }

    public Ticket(@NotNull String subject, @NotNull String ticketDescription, @NotNull Timestamp createdAt,
                  @NotNull String createdBy, @NotNull Timestamp dueDate, String updatedBy, Timestamp updatedAt,
                  @NotNull boolean ticketActivationFlag, @NotNull Status status, @NotNull Category category, User user) {

        this.subject = subject;
        this.ticketDescription = ticketDescription;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.dueDate = dueDate;
        this.updatedBy = updatedBy;
        this.updatedAt = updatedAt;
        this.ticketActivationFlag = ticketActivationFlag;
        this.status = status;
        this.category = category;
        this.user = user;

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTicketDescription() {
        return ticketDescription;
    }

    public void setTicketDescription(String ticketDescription) {
        this.ticketDescription = ticketDescription;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getDueDate() {
        return dueDate;
    }

    public void setDueDate(Timestamp dueDate) {
        this.dueDate = dueDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean getTicketActivationFlag() {
        return ticketActivationFlag;
    }

    public void setTicketActivationFlag(boolean ticketActivationFlag) {
        this.ticketActivationFlag = ticketActivationFlag;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public boolean isTicketActivationFlag() {
        return ticketActivationFlag;
    }

    public User getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(User assignedUser) {
        this.assignedUser = assignedUser;
    }

//    public Title getTitle() {
//        return title;
//    }
//
//    public void setTitle(Title title) {
//        this.title = title;
//    }

    public Blob getAttachment() {
        return attachment;
    }

    public void setAttachment(Blob attachment) {
        this.attachment = attachment;
    }

    public Timestamp getTicketDate() {
        return ticketDate;
    }

    public void setTicketDate(Timestamp ticketDate) {
        this.ticketDate = ticketDate;
    }
}
