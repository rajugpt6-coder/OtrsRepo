package com.techment.OtrsSystem.domain;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

@Entity
@Table(name = "tbl_ticket")
public class TicketGen {

    @Id
    @Column(name = "pk_ticket_id")
    private long id;

    @Column(name = "ticket_cat")
    @NotNull
    private String categoryName;

    @Column(name = "t_status")
    private boolean status;

    @Column(name = "ticket_title")
    private String title;

    @Column(name = "ticket_desc")
    private String description;

//    @OneToMany(cascade = CascadeType.ALL)
//    @JoinColumn(name = "fk_title")
//    private List<Title> titles;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "flag")
    private boolean flag;


    protected TicketGen(){}

    public TicketGen(@NotNull String categoryName) {
        this.categoryName = categoryName;
    }

    public TicketGen(@NotNull String categoryName, boolean status, String title) {
        this.categoryName = categoryName;
        this.status = status;
        this.title = title;
    }

    public TicketGen(long id, @NotNull String categoryName, boolean status, String titles, String description, Timestamp createdAt, String createdBy) {
        this.categoryName = categoryName;
        this.status = status;
        this.title = titles;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.description = description;
        this.id = id;

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }



    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
