package com.techment.OtrsSystem.repository;

import com.techment.OtrsSystem.domain.Log;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogRepository extends JpaRepository<Log, Long> {
}
