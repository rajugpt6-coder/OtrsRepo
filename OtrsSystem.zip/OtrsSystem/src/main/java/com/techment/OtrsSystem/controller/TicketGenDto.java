package com.techment.OtrsSystem.controller;

import javax.validation.constraints.NotNull;
import java.util.List;

public class TicketGenDto {

    private long issueId;

    @NotNull
    private String categoryName;

    private String title;

    private String description;

    protected TicketGenDto(){}

    public TicketGenDto(long issueId, @NotNull String categoryName, String title, String description) {
        this.categoryName = categoryName;
        this.title = title;
        this.description = description;
        this.issueId = issueId;
    }

    public String getCategoryName() {
        return categoryName;
    }



    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public long getId() {
        return issueId;
    }
}
