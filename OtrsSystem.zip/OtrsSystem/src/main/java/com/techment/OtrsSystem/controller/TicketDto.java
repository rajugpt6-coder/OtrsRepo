package com.techment.OtrsSystem.controller;

import javax.validation.constraints.NotNull;
import java.sql.Blob;

public class TicketDto {


    private String title;

    private String subject;

    private Blob attachment;

    @NotNull
    private String description;

    @NotNull
    private long categoryId;

    private String status;

    public TicketDto(String title, String description, long categoryId, String subject, Blob attachment) {
        this.title = title;
        this.description = description;
        this.categoryId = categoryId;
        this.subject = subject;
        this.attachment = attachment;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public String getStatus() {
        return status;
    }

    public String getSubject() {
        return subject;
    }

    public Blob getAttachment() {
        return attachment;
    }
}
