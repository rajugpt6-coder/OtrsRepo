package com.techment.OtrsSystem.controller;

import org.springframework.stereotype.Component;

@Component
public class TicketAssembler {
}
