package com.techment.OtrsSystem.controller;

import com.techment.OtrsSystem.domain.TicketGen;
import com.techment.OtrsSystem.service.TicketGenService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/users/{id}")
public class TicketGenController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    public TicketGenService ticketGenService;

    @PostMapping("/category")
    @PreAuthorize("hasAuthority('F_CREATE_CATEGORY')")
    @ResponseStatus(HttpStatus.CREATED)
    public Optional<TicketGen> ticketGenerate(@RequestBody @Validated TicketGenDto ticketGenDto, @PathVariable("id") Long id,
                                              @RequestHeader(value = "Authorization") String token){
        LOGGER.info("authorised");
        return Optional.ofNullable(ticketGenService.generateTicket(ticketGenDto.getCategoryName(), id, ticketGenDto.getId(),   token, ticketGenDto.getTitle(), ticketGenDto.getDescription()));

    }

    @PatchMapping("/delete/category/{issueId}")
    @PreAuthorize("hasAuthority('F_DELETE_CATEGORY')")
    @ResponseStatus(HttpStatus.CREATED)
    public String deleteTicket(@PathVariable("issueId") long issueId, @PathVariable("id") Long id,
                                 @RequestHeader(value = "Authorization") String token){
        LOGGER.info("authorised");
        return ticketGenService.deleteTicket(issueId, id, token);

    }
}
