package com.techment.OtrsSystem.controller;

import com.techment.OtrsSystem.domain.User;
import com.techment.OtrsSystem.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.NoSuchElementException;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);



    @PostMapping("{id}/updatePassword/oldPassword/{oldPassword}/newPassword/{newPassword}")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('F_UPDATE_PASSWORD')")
    public String updatePassword(@PathVariable("id") long id, @PathVariable("oldPassword") String oldPassword, @PathVariable("newPassword") String newPassword,
                                 @RequestHeader("Authorization") String token){
        return userService.updatePassword(id, oldPassword, newPassword, token);
    }

    @PatchMapping("{id}/updateProfile")
    @PreAuthorize("hasAuthority('F_UPDATE_PROFILE')")
    @ResponseStatus(HttpStatus.OK)
    public void updateProfile(@PathVariable("id") long id, @RequestBody UserDto userDto,
                                  @RequestHeader("Authorization") String token) {
        userService.updateProfile(id, userDto.getPhoneNumber(), userDto.getLandlineNumber(),
                userDto.getWorkingNumber(), userDto.getExtensionLandline(), userDto.getDesignation(), token);
    }

    @GetMapping("{id}/findByFeatures")
    @PreAuthorize("hasAuthority('F_GET_USERS_BY_FEATURES')")
    public Page<User> findUsersByFeatures(@RequestBody UserDto userDto, Pageable pageable) {
        return userService.getUsersByFeatures(userDto.getFeatureAccessList(), pageable);
    }

    @PatchMapping("{id}/deactivate/{userId}")
    @PreAuthorize("hasAuthority('F_DEACTIVATE_USER')")
    @ResponseStatus(HttpStatus.OK)
    public void deactivateUser(@PathVariable("userId") long userId) {
        userService.deactivateUser(userId);
    }

    @PatchMapping("{id}/activate/{userId}")
    @PreAuthorize("hasAuthority('F_ACTIVATE_USER')")
    @ResponseStatus(HttpStatus.OK)
    public void activateUser(@PathVariable("userId") long userId) {
        userService.activateUser(userId);
    }

    @PatchMapping("{id}/addFeatureAccess/{userId}")
    @PreAuthorize("hasAuthority('F_ADD_FEATURE_ACCESS')")
    @ResponseStatus(HttpStatus.OK)
    public void addFeatureAccess(@PathVariable("userId") long userId, @RequestBody UserDto userDto){
        LOGGER.info(String.valueOf(userDto.getFeatureAccessList()));
        userService.setFeaturesAccess(userId, userDto.getFeatureAccessList());
    }

    @PatchMapping("removeFeatures/{userId}")
    @PreAuthorize("hasAuthority('F_REMOVE_FEATURE_ACCESS')")
    public void removeFeatures(@PathVariable("userId") long userId, @RequestBody UserDto userDto){
            userService.removeFeatureAccess(userId, userDto.getFeatureAccessList());
    }

    @GetMapping
    @PreAuthorize("hasAuthority('F_GET_ALL_USERS')")
    public Page<User> getAllUsers(Pageable pageable) {
        return  userService.getAll(pageable);
    }


    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('F_GET_USER_DETAILS')")
    public User getUserDetails(@PathVariable("id") long id) {
        return userService.findUserById(id).orElseThrow(() -> new NoSuchElementException("User " + id + " not found"));
    }

    @GetMapping("/myDetails/{email}")
    @PreAuthorize("hasAuthority('F_GET_MY_DETAILS')")
    public User getMyDetails(@PathVariable("email") String email, @RequestHeader(value="Authorization") String token ) {
        return userService.findUserByEmail(email, token);
    }

    //
    @GetMapping("/search/employeeId/{employeeId}")
    @PreAuthorize("hasAuthority('F_GET_USERS_BY_EMPLOYEE_ID')")
    public Page<User> getUsersByEmployeeId(@PathVariable("employeeId") String employeeId, Pageable pageable) {
        return userService.findUsersByEmployeeId(employeeId, pageable);
    }

    @GetMapping("/search/firstName/{firstName}")
    @PreAuthorize("hasAuthority('F_GET_USERS_BY_FIRST_NAME')")
    public Page<User> getUsersByFirstName(@PathVariable("firstName") String firstName, Pageable pageable) {
        return userService.findUsersByFirstName(firstName, pageable);
    }

    @GetMapping("/search/activationStatus/{flag}")
    @PreAuthorize("hasAuthority('F_GET_USERS_BY_ACTIVATION_STATUS')")
    public Page<User> getUsersByActivationStatus(@PathVariable("flag") boolean flag, Pageable pageable) {
        return userService.findUsersByFlag(flag, pageable);
    }

    @GetMapping("/search/email/{email}")
    @PreAuthorize("hasAuthority('F_GET_USER_BY_EMAIL')")
    public User getUserByEmail(@PathVariable("email") String email) {
        return userService.findByEmail(email);
    }

    @GetMapping("/search/phoneNumber/{phoneNumber}")
    @PreAuthorize("hasAuthority('F_GET_USERS_BY_PHONE')")
    public Page<User> getUsersByPhone(@PathVariable("phoneNumber") String phoneNumber, Pageable pageable) {
        return userService.findByPhoneNumber(phoneNumber, pageable);
    }

    @GetMapping("/search/department/{department}")
    @PreAuthorize("hasAuthority('F_GET_USERS_BY_DEPARTMENT')")
    public Page<User> getUsersByDepartment(@PathVariable("department") String department, Pageable pageable){
        return userService.findByDepartment(department, pageable);
    }

    @GetMapping("/search/designation/{designation}")
    @PreAuthorize("hasAuthority('F_GET_USERS_BY_DESIGNATION')")
    public Page<User> getUsersByDesignation(@PathVariable("designation") String designation, Pageable pageable) {
        return userService.findByDesignation(designation, pageable);
    }

}
