package com.techment.OtrsSystem.repository;

import com.techment.OtrsSystem.domain.TicketGen;
import com.techment.OtrsSystem.domain.Status;
import com.techment.OtrsSystem.domain.Ticket;
import com.techment.OtrsSystem.domain.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.sql.Timestamp;

@RepositoryRestResource(exported = false)
public interface TicketRepository extends PagingAndSortingRepository<Ticket, Long> {
    Page<Ticket> findByUser(User user, Pageable pageable);

    Page<Ticket> findByAssignedUser(User user, Pageable pageable);

//    Page<Ticket> findByCategoryAndStatus(TicketGen ticketGen, Status status, Pageable pageable);

    //searching
    Page<Ticket> findBySubjectIgnoreCaseContaining(String subject, Pageable pageable);

    Page<Ticket> findBySubjectAndUserIgnoreCaseContaining(String subject, User user, Pageable pageable);

    Page<Ticket> findByStatus(Status status, Pageable pageable);

    Page<Ticket> findByStatusAndUser(Status status, User user, Pageable pageable);

    Page<Ticket> findByDueDate(Timestamp date, Pageable pageable);

//    Page<Ticket> findByCategory(TicketGen ticketGen, Pageable pageable);

    Page<Ticket> findByCreatedAt(Timestamp createdAt, Pageable pageable);

    //searching end

//    long countTicketByCategory(TicketGen ticketGen);

//    long countTicketByCategoryAndStatus(TicketGen ticketGen, Status status);
}
