package com.techment.OtrsSystem.controller;

import javax.validation.constraints.NotNull;
import java.util.List;

public class CategoryDto {

    @NotNull
    private String categoryName;

    private String title;

    private String description;

    protected CategoryDto(){}

    public CategoryDto(@NotNull String categoryName, String title, String description) {
        this.categoryName = categoryName;
        this.title = title;
        this.description = description;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }
}
